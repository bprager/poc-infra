def lambda_handler(event, context):
    message = event.get('message')
    responseMsg = {
        'statusCode' : '200',
        'body': f'Hi, you message was: {message} ',
        'headers' : {
            'Access-Control-Allow-Origin' : '*'
        }
    }
    return responseMsg
